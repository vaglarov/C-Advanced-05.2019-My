﻿namespace CarSalesman
{
    internal class Dictionary<T>
    {
        public Dictionary()
        {
        }
    }
}