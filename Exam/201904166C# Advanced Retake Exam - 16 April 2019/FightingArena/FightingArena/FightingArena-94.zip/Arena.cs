﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FightingArena
{
    public class Arena
    {
        private Dictionary<string, Gladiator> dictAredna;
        public Arena(string name)
        {
            dictAredna = new Dictionary<string, Gladiator>();
            Name = name;
        }
        public string Name { get; set; }
        public void Add(Gladiator gladiator)
        {
            if (!dictAredna.ContainsKey(gladiator.Name))
            {
                dictAredna.Add(gladiator.Name, gladiator);
            }
        }
        public void Remove(string name)
        {
            if (dictAredna.ContainsKey(name))
            {
                dictAredna.Remove(name);
            }
        }

        public Gladiator GetGladitorWithHighestStatPower()
        {
            var result = dictAredna.Values.OrderByDescending(x => x.GetStatPower()).FirstOrDefault();
            return result;
        }
        public Gladiator GetGladitorWithHighestWeaponPower()
        {
            var result = dictAredna.Values.OrderByDescending(x => x.GetWeaponPower()).FirstOrDefault();
            return result;
        }
        public Gladiator GetGladitorWithHighestTotalPower()
        {
            var result = dictAredna.Values.OrderByDescending(x => x.GetTotalPower()).FirstOrDefault();
            return result;
        }
        public int Count => dictAredna.Count;
        public override string ToString()
        {
            return $"[{Name}] - [{Count}] gladiators are participating.";
        }

    }
}
