﻿using System;

namespace FightingArena
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

          
            




        }
    }
}
