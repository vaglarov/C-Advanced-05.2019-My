﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FightingArena
{
    public class Arena
    {
        private Dictionary<string, Gladiator> gladiators;
        public Arena(string name)
        {
            gladiators = new Dictionary<string, Gladiator>();
            Name = name;
        }
        public string Name { get; set; }
        public void Add(Gladiator gladiator)
        {

            gladiators.Add(gladiator.Name, gladiator);
        }
        public void Remove(string name)
        {
                gladiators.Remove(name);
        }

        public Gladiator GetGladitorWithHighestStatPower()
        {
            var result = gladiators.Values.OrderByDescending(x => x.GetStatPower()).FirstOrDefault();
            return result;
        }
        public Gladiator GetGladitorWithHighestWeaponPower()
        {
            var result = gladiators.Values.OrderByDescending(x => x.GetWeaponPower()).FirstOrDefault();
            return result;
        }
        public Gladiator GetGladitorWithHighestTotalPower()
        {
            var result = gladiators.Values.OrderByDescending(x => x.GetTotalPower()).FirstOrDefault();
            return result;
        }
        public int Count => gladiators.Count;
        public override string ToString()
        {
            return $"{Name} - {Count} gladiators are participating.";
        }

    }
}
