﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace GenericSwapMethodString
{
    public class GenericItem<T> 
    {
      
        private List<T> elements;
        public GenericItem()
        {
            elements = new List<T>();
        }
        public T Element { get; set; }
        public void Add(T element)
        {
            elements.Add(element);
        }
        public void Swap(int firstIndex,int secondIndex)
        {
            var tempElement = elements[firstIndex];
            elements[firstIndex] = elements[secondIndex];
            elements[secondIndex] = tempElement;
        }
        public int Count()
        {
            return elements.Count;
        }

        public void PrintForeach()
        {
            foreach (var item in elements)
            {
                Console.WriteLine($"{item.GetType()}: {item}");
            }
        }

        public override string ToString()
        {
            return $"{Element.GetType()}: {Element}";
        }
       
        
    }
}
